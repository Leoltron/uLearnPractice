using System;
using System.Drawing;

namespace RoutePlanning
{
	public static class PathFinderTask
	{
		public static int[] FindBestCheckpointsOrder(Point[] checkpoints)
		{
			var bestPath = new int[checkpoints.Length];
		    var bestPathLength = double.MaxValue;
            var path = new int[checkpoints.Length];
		    MakeBestPermutation(checkpoints, path, 1, 0d, ref bestPath, ref bestPathLength);
		    return bestPath;

		}

		private static void MakeBestPermutation(Point[] checkpoints, int[] currentPath,int position,double currentSum,ref int[] bestPath, ref double bestPathLength, double optimalLength = 0)
		{
		    if (position == currentPath.Length)
		    {
		            bestPathLength = currentSum;
		            currentPath.CopyTo(bestPath, 0);
		    }
		    else
		    {
		        for (var i = 1; i < currentPath.Length; i++)
		        {
		            if (optimalLength >= bestPathLength)
		                return;

                        var index = Array.IndexOf(currentPath, i, 0, position);
		            if (index != -1)
		                continue;
		            var length = GetDistance(checkpoints[currentPath[position-1]],checkpoints[i]);
		            if (currentSum + length >= optimalLength)
                        continue;
                    currentPath[position] = i;
                    MakeBestPermutation(checkpoints, currentPath, position + 1, currentSum + length,ref bestPath, ref bestPathLength, optimalLength);
		        }
		    }
		}

	    private static double GetDistance(Point a, Point b)
	    {
	        return Math.Sqrt((a.X - b.X)*(a.X - b.X) + (a.Y - b.Y)*(a.Y - b.Y));
	    }

	    public static int[] FindOptimalCheckpointsOrder(Point[] checkpoints, double optimalLength)
	    {
            var optimalPath = new int[checkpoints.Length];
            var optimalPathLength = double.MaxValue;
            var path = new int[checkpoints.Length];
            MakeBestPermutation(checkpoints, path, 1, 0d, ref optimalPath, ref optimalPathLength,optimalLength);
            return optimalPath;
        }
	}
}
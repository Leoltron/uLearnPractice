﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TextAnalysis
{
	static class BigramGeneratorTask
	{
		public static string ContinuePhraseWithBigramms(Dictionary<string, string> mostFrequentNextWords, string phraseBeginning, int phraseWordsCount)
		{
            var wordsAmount = 1;
            var phrase = phraseBeginning;
            var lastWord = phraseBeginning;

            while (mostFrequentNextWords.ContainsKey(lastWord) && wordsAmount < phraseWordsCount)
            {
                lastWord = mostFrequentNextWords[lastWord];
                phrase += " " + lastWord;
                wordsAmount++;
            }

            return phrase;
        }

        public static string ContinuePhraseWithRandomBigramms(Dictionary<string, Dictionary<string, int>> mostFrequentNextWords, string phraseBeginning, int phraseWordsCount, Random rand)
        {
            var wordsAmount = 1;
            var phrase = phraseBeginning;
            var lastWord = phraseBeginning;

            while (mostFrequentNextWords.ContainsKey(lastWord) && wordsAmount < phraseWordsCount)
            {
                lastWord = GetRandomWord(mostFrequentNextWords[lastWord],rand);
                phrase += " " + lastWord;
                wordsAmount++;
            }

            return phrase;
        }

	    private static string GetRandomWord(Dictionary<string, int> wordsCount, Random rand)
	    {
	        var sum = wordsCount.Sum(wordCount => wordCount.Value);
	        var num = rand.Next(sum);
	        foreach (var wordCount in wordsCount)
	        {
                num -= wordCount.Value;
	            if (num <= 0)
	                return wordCount.Key;
	        }
	        return "";
	    }


    }
}
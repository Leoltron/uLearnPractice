﻿using System.Collections.Generic;
using System.Linq;

namespace TextAnalysis
{
	static class FrequencyAnalysisTask
	{
        /*
		Постройте по тексту словарь наиболее вероятного продолжения текста.

		Ключи этого словаря — это все слова, с которых начинается хотя бы одна биграмма исходного текста.
		В качестве значения должно быть второе слово самой частой биграммы, начинающейся с ключа.
		Если есть несколько биграмм с одинаковой частотой, то использовать лексикографически первую
		(используйте способ сравнения Ordinal, например с помощью метода string.CompareOrdinal).
		*/
        private static string GetMaxKey(Dictionary<string,int> dictionary)
        {
            var isMaxKeyEmpty = true;
            var maxKey = "";

            foreach (var key in dictionary.Keys)
                if (isMaxKeyEmpty)
                {
                    maxKey = key;
                    isMaxKeyEmpty = false;
                }
                else if((dictionary[key] == dictionary[maxKey] && string.CompareOrdinal(key, maxKey) < 0)
                    || dictionary[key] > dictionary[maxKey])
                    maxKey = key;

            return maxKey;
        }

        public static Dictionary<string, string> GetMostFrequentNextWords(IEnumerable<List<string>> text)
        {
            var nextWordsAppearanceCount = CountNextWordsAppearanceCount(text);

            return nextWordsAppearanceCount.Keys.ToDictionary(key => key, key => GetMaxKey(nextWordsAppearanceCount[key]));

        }

        public static Dictionary<string, Dictionary<string, int>> CountNextWordsAppearanceCount(IEnumerable<List<string>> text)
	    {
            var nextWordsAppearanceCount = new Dictionary<string, Dictionary<string, int>>();
            foreach (var sentenceForFirstWord in text)
	            for (var i = 0; i < sentenceForFirstWord.Count - 1; i++)
	            {
	                if (!nextWordsAppearanceCount.ContainsKey(sentenceForFirstWord[i]))
	                    nextWordsAppearanceCount.Add(sentenceForFirstWord[i], new Dictionary<string, int>());

	                var secondWordAppearanceCount = nextWordsAppearanceCount[sentenceForFirstWord[i]];
	                if (!secondWordAppearanceCount.ContainsKey(sentenceForFirstWord[i + 1]))
	                    secondWordAppearanceCount.Add(sentenceForFirstWord[i + 1], 0);

	                secondWordAppearanceCount[sentenceForFirstWord[i + 1]]++;
	            }
	        return nextWordsAppearanceCount;

	    }
	}
}
﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TextAnalysis
{
	static class SentencesParserTask
	{
		public static readonly string[] StopWords = { "the", "and", "to", "a", "of", "in", "on", "at", "that", "as", "but", "with", "out", "for", "up", "one", "from", "into" };

        private static readonly char[] SentencesSeparators = { '.', '!', '?', ';', ':', '(', ')' };
        /*
		Разбейте файл с текстом на предложения и слова. 
		Считайте, что слова могут состоять только из букв (используйте метод char.IsLetter) или символа апострофа ',
		а предложения разделены одним из следующих символов .!?;:()
		Удалите из файла слова, содержащиеся в массиве StopWords (частые незначащие слова при анализе текстов называют стоп-словами)
		Метод должен возвращать список предложений, где каждое предложение — это список оставшихся слов в нижнем регистре.
		*/
        public static List<List<string>> ParseSentences(string text)
		{
            var parsedSentencesList = new List<List<string>>();

            foreach(var sentence in text.Split(SentencesSeparators))
            {
                var nonLetterCharacters = new List<char>();
                var modifiedSentence = sentence;
                foreach (var ch in modifiedSentence.ToCharArray())
                    if (!(char.IsLetter(ch) || ch == '\'') && !nonLetterCharacters.Contains(ch))
                        nonLetterCharacters.Add(ch);

                var parsedSentence = new List<string>(modifiedSentence.ToLower().Split(nonLetterCharacters.ToArray(),StringSplitOptions.RemoveEmptyEntries));

                parsedSentence.RemoveAll(string.IsNullOrWhiteSpace);
                parsedSentence.RemoveAll(StopWords.Contains);

                if(parsedSentence.Count > 0)
                    parsedSentencesList.Add(parsedSentence);
            }

            return parsedSentencesList;
        }
	}
}
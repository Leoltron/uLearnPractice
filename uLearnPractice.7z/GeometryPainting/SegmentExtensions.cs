﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using GeometryTasks;

namespace GeometryPainting
{
    public class ColorHolder
    {
        public ColorHolder(Color color)
        {
            this.color = color;
        }
        public Color color;
    }
    public static class SegmentExtensions
    {
        private static readonly Color defaultColor = Color.Black;
        public static ConditionalWeakTable<Segment,ColorHolder> Colors = new ConditionalWeakTable<Segment, ColorHolder>();

        public static Color GetColor(this Segment segment)
        {
            ColorHolder colorHolder;
            return Colors.TryGetValue(segment, out colorHolder) ? colorHolder.color : defaultColor;
        }

        public static void SetColor(this Segment segment,Color color)
        {
            Colors.Remove(segment);
            Colors.Add(segment,new ColorHolder(color));
        }
    }
}

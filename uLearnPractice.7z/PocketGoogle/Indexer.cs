﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PocketGoogle
{
    public class Indexer : IIndexer
    {
        private Dictionary<int, List<Tuple<string, int>>> docWordIdsEntries =
            new Dictionary<int, List<Tuple<string, int>>>();
        private Dictionary<string, List<int>> wordIds = new Dictionary<string, List<int>>();
        private Dictionary<int, Dictionary<string, List<int>>> documentDictionary =
            new Dictionary<int, Dictionary<string, List<int>>>();

        private readonly char[] dividers = { ' ', '.', ',', '!', '?', ':', '-', '\r', '\n' };
        public void Add(int id, string documentText)
        {
            documentDictionary.Add(id, GetPositionsDic(id, documentText));
        }

        private Dictionary<string, List<int>> GetPositionsDic(int id, string documentText)
        {
            var positions = new Dictionary<string, List<int>>();
            var words = documentText.Split(dividers);
            var firstIndex = 0;
            foreach (var word in words)
            {
                if (!positions.ContainsKey(word))
                    positions[word] = new List<int>();
                positions[word].Add(firstIndex);
                firstIndex += word.Length + 1;
            }

            FillWordIds(id, positions);
            return positions;
        }

        private void FillWordIds(int id, Dictionary<string, List<int>> positions)
        {
            var entries = new List<Tuple<string, int>>();
            foreach (var entry in positions)
            {
                if (!wordIds.ContainsKey(entry.Key))
                    wordIds[entry.Key] = new List<int>();
                entries.Add(new Tuple<string, int>(entry.Key, wordIds[entry.Key].Count));
                wordIds[entry.Key].Add(id);
            }

            docWordIdsEntries.Add(id, entries);
        }

        public List<int> GetIds(string word)
        {
            var list = new List<int>();
            if (wordIds.ContainsKey(word))
                list = wordIds[word].Where(id => id >= 0).ToList();
            return list;
        }

        public List<int> GetPositions(int id, string word)
        {
            if (documentDictionary.ContainsKey(id) && documentDictionary[id].ContainsKey(word))
                return documentDictionary[id][word];

            return new List<int>();
        }

        public void Remove(int id)
        {
            documentDictionary.Remove(id);
            
            foreach (var entry in docWordIdsEntries[id])
                wordIds[entry.Item1].Remove(entry.Item2);
            docWordIdsEntries.Remove(id);


        }
    }
}

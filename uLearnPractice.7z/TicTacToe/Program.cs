﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe
{
    class Program
    {
        public enum Mark
        {
            Empty,
            Cross,
            Circle
        }

        public enum GameResult
        {
            CrossWin,
            CircleWin,
            Draw
        }

        private enum AdvancedGameResult
        {
            CrossWin,
            CircleWin,
            Draw,
            DoubleWin
        }

        public static float B(float n)
        {
            float s = 0.0f;
            for (float i = 1; i <= n; i++)
                s += (float)i / n  * (i % 2 == 1 ? 1 : -1);
            return Math.Abs(s);
        }

        public static void Main()
        {
            for (float i = 1; i < 20; i++)
                Console.WriteLine(B(i));


            Console.ReadLine();
        }

        private static void Check(string description)
        {
            Console.WriteLine(description.Replace(" ", "\r\n"));
            Console.WriteLine(GetGameResult(CreateFromString(description)));
            Console.WriteLine();
        }

        public static GameResult GetGameResult(Mark[,] field)
        {
            AdvancedGameResult gameRes = AdvancedGameResult.Draw;

            Mark[] row = new Mark[3];
            Mark[] column = new Mark[3];

            for (int i=0; i < 3; i++)
            {
                for(int k=0; k <3; k++)
                {
                    row[k] = field[k, i];
                    column[k] = field[i, k];
                }
                gameRes = ModifyResultByLine(gameRes, row);
                gameRes = ModifyResultByLine(gameRes, column);
            }

            gameRes = ModifyResultByLine(gameRes, new Mark[] { field[0, 0], field[1, 1], field[2, 2], });
            gameRes = ModifyResultByLine(gameRes, new Mark[] { field[0, 2], field[1, 1], field[0, 2], });

            return GetGameResult(gameRes);

        }

        public static Mark[,] CreateFromString(string desc)
        {
            string[] lines = desc.Split(' ');
            char[][] charLines = new char[lines.Length][];

            for (int i = 0; i < lines.Length; i++)
                charLines[i] = lines[i].ToCharArray(); 

            Mark[,] field = new Mark[3, 3];
            
            for (var x = 0; x < 3; x++)
                for (var y = 0; y < 3; y++)                 
                    field[y,x] = TransformCharToMark(charLines[y][x]);                

            return field;

        }

        public static Mark TransformCharToMark(char c)
        {
            switch (c)
            {
                case 'X':
                    return Mark.Cross;
                case 'O':
                    return Mark.Circle;
                default:
                    return Mark.Empty;
            }
        }

        public static Mark GetWinningByLine(Mark[] line)
        {
            for (var i = 1; i < line.Length; i++)
                if (line[i] != line[i - 1])
                    return Mark.Empty;
            return line[0];
        }

        private static AdvancedGameResult ModifyResultByLine(AdvancedGameResult result, Mark[] line)
        {
            if (result == AdvancedGameResult.DoubleWin || GetWinningByLine(line) == Mark.Empty)
                return result;
            else
            {
                switch (line[0])
                {
                    case Mark.Circle:
                        if (result == AdvancedGameResult.CircleWin || result == AdvancedGameResult.Draw)
                            return AdvancedGameResult.CircleWin;
                        else
                            return AdvancedGameResult.DoubleWin;
                    case Mark.Cross:
                        if (result == AdvancedGameResult.CrossWin || result == AdvancedGameResult.Draw)
                            return AdvancedGameResult.CrossWin;
                        else
                            return AdvancedGameResult.DoubleWin;
                    default:
                        return result;
                }
            }
        }

        private static GameResult GetGameResult(AdvancedGameResult advGameRes)
        {
            switch (advGameRes)
            {
                case AdvancedGameResult.CircleWin:
                    return GameResult.CircleWin;
                case AdvancedGameResult.CrossWin:
                    return GameResult.CrossWin;
                default:
                    return GameResult.Draw;
            }
        }

        private static string DecodeMessage(string[] lines)
        {
            List<string> words = new List<string>();
            foreach(string line in lines)
                words.AddRange(line.Split(' ').ToList());

            words = words.FindAll(
                delegate (string str)
                {
                    return str[0] == str.ToUpper()[0];
                }
                );

            string decodedMessage = "";

            words.Reverse();

            foreach (string word in words)
                if (decodedMessage.Length > 0)
                    decodedMessage = decodedMessage + " " + word;
                else
                    decodedMessage = word;

            return decodedMessage;
        }

    }
}

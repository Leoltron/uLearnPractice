using System;

namespace DistanceTask
{
    public static class DistanceTask
    {
        public static double GetDistanceToSegment(double ax, double ay, double bx, double by, double x, double y)
        {
            if (ax == bx && ay == by)
                return DistanceBetweenPoints(ax, ay, x, y);

            return 
                GetScalarProductOfVectors(ax - bx, ay - by, ax - x, ay - y) < 0 ||
                GetScalarProductOfVectors(bx - ax, by - ay, bx - x, by - y) < 0 ?
                Math.Min(DistanceBetweenPoints(ax, ay, x, y), DistanceBetweenPoints(bx, by, x, y)) :
                GetDistanceToVector(ax, ay, bx, by, x, y);
        }

        private static double GetDistanceToVector(double ax, double ay, double bx, double by, double x, double y)
        {
            return Math.Abs(((ay - by) * x + (bx - ax) * y + (ax * by - bx * ay)) / Math.Sqrt(Sqr(bx - ax) + Sqr(by - ay)));
        }

        public static double GetScalarProductOfVectors(double x1,double y1,double x2,double y2)
        {
            return x1 * x2 + y1 * y2;
        }

        public static double Sqr(double a)
        {
            return a * a;
        }

        public static double DistanceBetweenPoints(double x1, double y1, double x2, double y2)
        {
            return Math.Sqrt(Sqr(x1 - x2) + Sqr(y1 - y2));
        }
	}
}
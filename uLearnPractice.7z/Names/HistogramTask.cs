﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Names
{
    internal static class HistogramTask
    {
        private const int DaysInMonth = 31;
        private const int MonthInYear = 12;

        public static string[] getNumLabels(int startNumber, int labelsAmount)
        {
            string[] numLabels = new string[labelsAmount];
            for (var i = 0; i < labelsAmount; i++)
                numLabels[i] = (i + startNumber).ToString();
            return numLabels;
        }

        public static HistogramData GetHistogramBirthsPerDay(NameData[] names, string name)
        {          
            double[] daysBirths = new double[DaysInMonth];

            foreach (NameData nameData in names)
                if (nameData.Name == name && nameData.BirthDate.Day != 1)
                    daysBirths[nameData.BirthDate.Day - 1]++;

            return new HistogramData(String.Format("Рождаемость людей с именем '{0}'", name), getNumLabels(1, DaysInMonth), daysBirths);
        }

        public static HistogramData GetHistogramBirthsPerMonth(NameData[] names, string name)
        {
            double[] monthsBirths = new double[MonthInYear];

            foreach (NameData nameData in names)
                if (nameData.Name == name )
                    monthsBirths[nameData.BirthDate.Month - 1]++;

            return new HistogramData(String.Format("Рождаемость людей с именем '{0}'", name), getNumLabels(1, MonthInYear), monthsBirths);
       }

        public static HistogramData GetHistogramBirthsPerYear(NameData[] names)
        {
            var minYear = int.MaxValue;
            var maxYear = 0;
            foreach (NameData nameData in names)
            {
                minYear = Math.Min(nameData.BirthDate.Year, minYear);
                maxYear = Math.Max(nameData.BirthDate.Year, maxYear);
            }
            double[] yearsBirths = new double[maxYear-minYear+1];
            foreach (NameData nameData in names)
                yearsBirths[nameData.BirthDate.Year - minYear]++;

            return new HistogramData("Рождаемость людей по годам", getNumLabels(minYear, maxYear - minYear + 1), yearsBirths);
        }
    }
}
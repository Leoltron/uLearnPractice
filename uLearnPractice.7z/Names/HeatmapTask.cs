﻿using System;

namespace Names
{
	internal static class HeatmapTask
	{
		public static string[] GetNumLabels(int startNumber, int labelsAmount)
		{
			string[] numLabels = new string[labelsAmount];
            for (var i = 0; i < labelsAmount; i++)
                numLabels[i] = (i + startNumber).ToString();
			return numLabels;
		}

		public static HeatmapData GetHistogramBirthsPerDate(NameData[] names)
		{
            var daysInMonth = 30;
            var monthsInYear = 12;

            double[,] heatData = new double[daysInMonth, monthsInYear];

            foreach (NameData data in names)
                if (data.BirthDate.Date.Day != 1)
                    heatData[data.BirthDate.Date.Day - 2, data.BirthDate.Date.Month - 1]++;

            return new HeatmapData("Статистика рождаемости по дням", heatData, GetNumLabels(2, daysInMonth), GetNumLabels(1, monthsInYear));
		}
    }
}
﻿namespace Mazes
{
	public static class DiagonalMazeTask
	{
		public static void MoveOut(Robot robot, int width, int height)
		{
            bool isRightStepLonger = width > height;

            int simplifiedPathWidth = width - (isRightStepLonger ? 3 : 2);
            int simplifiedPathHeight = height - (isRightStepLonger ? 2 : 3);

            int gcd = GCD(simplifiedPathWidth, simplifiedPathHeight);

            int stepRightLength = (simplifiedPathWidth) / gcd;
            int stepDownLength = (simplifiedPathHeight) / gcd;

            while (!robot.Finished)
            {
                Move(robot, isRightStepLonger ? Direction.Right : Direction.Down, isRightStepLonger ? stepRightLength : stepDownLength);
                Move(robot, isRightStepLonger ? Direction.Down : Direction.Right, isRightStepLonger ? stepDownLength : stepRightLength);
            }
        }

        public static void Move(Robot robot, Direction direction, int length)
        {
            for (var i = 0; i < length && !robot.Finished; i++)
                robot.MoveTo(direction);
        }

        public static int GCD(int a, int b)
        {
            return b == 0 ? a : GCD(b, a % b);
        }
	}
}
﻿namespace Mazes
{
	public static class PyramidMazeTask
	{
		public static void MoveOut(Robot robot, int width, int height)
		{
            int lineLength = width - 3;
            bool isDirRight = true;
            while (!robot.Finished)
            {
                Move(robot,isDirRight ? Direction.Right : Direction.Left, lineLength);
                Move(robot, Direction.Up, 2);
                lineLength -= 2;
                isDirRight = !isDirRight;
            }
		}

        public static void Move(Robot robot, Direction direction, int length)
        {
            for (var i = 0; i < length && !robot.Finished; i++)
                robot.MoveTo(direction);
        }
    }
}
﻿namespace Mazes
{
	public static class SnakeMazeTask
	{
        public static void MoveOut(Robot robot, int width, int height)
        {
            while (!robot.Finished)
            {
                Move(robot, Direction.Right, width - 3);
                Move(robot, Direction.Down,2);
                Move(robot, Direction.Left, width - 3);
                Move(robot, Direction.Down,2);
            }
        }

        public static void Move(Robot robot, Direction direction, int length)
        {
            for (var i = 0; i < length && !robot.Finished; i++)
                robot.MoveTo(direction);
        }        
    }
}
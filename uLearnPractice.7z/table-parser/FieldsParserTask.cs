using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace TableParser
{
    public class FieldsParserTask
    {
        public static List<string> ParseLine(string line)
        {
            return new FieldsParser().ParseString(line);
        }
    }

    public class FieldsParser
    {
        private char separator;
        private string line;
        private int currentIndex;

        public List<string> ParseString(string str)
        {
            var fieldsList = new List<string>();
            var builder = new StringBuilder();

            separator = ' ';

            line = str;
            for (currentIndex = 0; currentIndex < line.Length; currentIndex++)
            {
                var ch = line[currentIndex];
                if (IsSpecialSymbol(ch))
                    ParseCurrentSymbolAsSpecial(builder,fieldsList);
                else
                    ParseCurrentSymbolAsCommon(builder, fieldsList);
            }
            ParseRemains(builder, fieldsList);
            return fieldsList;
        }

        private void ParseCurrentSymbolAsSpecial(StringBuilder builder, List<string> fieldsList)
        {
            if (IsQuote(line[currentIndex]))
                ParseSeparatorSymbol(builder,fieldsList);
            else
                ParseBackslash(builder);
        }

        private void ParseCurrentSymbolAsCommon(StringBuilder builder, List<string> fieldsList)
        {
            if (separator == ' ' && line[currentIndex] == ' ')
            {
                if (builder.Length <= 0) return;
                fieldsList.Add(builder.ToString().Trim());
                builder.Clear();
            }
            else
                builder.Append(line[currentIndex]);
        }

        private void ParseRemains(StringBuilder builder, List<string> fieldsList)
        {
            if (IsQuote(separator))
                fieldsList.Add(builder.ToString());
            else if (!string.IsNullOrWhiteSpace(builder.ToString()))
                fieldsList.Add(builder.ToString().Trim());
        }

        private void ParseSeparatorSymbol(StringBuilder builder, List<string> fieldsList)
        {
            if (line[currentIndex] != separator)
            {
                if (line[currentIndex] == separator)
                {
                    separator = ' ';
                    fieldsList.Add(builder.ToString());
                    builder.Clear();
                }
                else if (IsQuote(separator))
                    builder.Append(line[currentIndex]);
                else
                {
                    separator = line[currentIndex];
                    if (!string.IsNullOrWhiteSpace(builder.ToString()))
                        fieldsList.Add(builder.ToString().Trim());
                    builder.Clear();
                }
            }
            else
            {
                separator = ' ';
                fieldsList.Add(builder.ToString());
            }

        }

        private void ParseBackslash(StringBuilder builder)
        {
            if (currentIndex == 0 || currentIndex == line.Length - 1)
                builder.Append('\\');
            else
            {
                currentIndex++;
                builder.Append(line[currentIndex]);
            }
        }

        private static bool IsSpecialSymbol(char symbol)
        {
            return IsQuote(symbol) || symbol == '\\';
        }

        private static bool IsQuote(char symbol)
        {
            return symbol == '\'' || symbol == '\"';
        }
    }
}
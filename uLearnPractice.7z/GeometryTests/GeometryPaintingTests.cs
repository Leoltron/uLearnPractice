﻿using System;
using System.Diagnostics;
using System.Drawing;
using GeometryPainting;
using GeometryTasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GeometryTests
{
    [TestClass]
    public class GeometryPaintingTests
    {
        private const int RepetitionsCount = 10000000;
        [TestMethod]
        public void MemoryWasteTest()
        {
            var currentProcess = Process.GetCurrentProcess();
            var memorySizeBefore = currentProcess.WorkingSet64;
            var rand = new Random();
            for (var i = 0; i < RepetitionsCount; i++)
            {
                var segment = GetRandomSegment(rand,1000);
                segment.SetColor(GetRandomColor(rand));
            }

            GC.Collect();
            var memorySizeAfter = currentProcess.WorkingSet64;
            Assert.AreEqual(memorySizeBefore,memorySizeAfter);

        }

        private Vector GetRandomVector(Random rand, double radius)
        {
            return new Vector();
        }

        private Segment GetRandomSegment(Random rand, double radius)
        {
            return new Segment(
                GetRandomVector(rand, radius),
                GetRandomVector(rand, radius));
        }

        private Color GetRandomColor(Random rand)
        {
            return Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256), rand.Next(256));
        }
    }
}

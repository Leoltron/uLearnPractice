﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace GravityBalls
{
	public class WorldModel
	{
        public BallsForm Form;
        public double BallX;
		public double BallY;
		public double BallRadius;
		public double WorldWidth;
		public double WorldHeight;

        public Brush BallColor;

        public double VelY = 0;
        public double VelX = 0;

        private double resistCoefficent = 0;

        private const double g = 9.80665;
        private bool isGravityOn = true;
        private bool isCursorForceOn = true;

        public void SimulateTimeframe(double dt)
		{
            double cursorForce = isCursorForceOn ? 100 : 0;

            double cursorDistanceX = BallX - Form.GetCursorX();
            double cursorForceX = Math.Min(cursorForce,(cursorDistanceX < 0 ? -1 : 1) * cursorForce / (cursorDistanceX * cursorDistanceX));

            double cursorDistanceY = BallY - Form.GetCursorY();
            double cursorForceY = Math.Min(cursorForce,(cursorDistanceY < 0 ? -1 : 1) * cursorForce / (cursorDistanceY * cursorDistanceY));

            BallY = Math.Max(BallRadius, Math.Min(BallY + VelY * dt - dt * resistCoefficent, WorldHeight - BallRadius));

            if (WorldHeight - BallRadius == BallY || BallRadius == BallY)
                VelY = -VelY;

            VelY += (isGravityOn ? g * 10 : 0) + cursorForceY;

            BallX = Math.Max(BallRadius,Math.Min(BallX + VelX * dt - dt * resistCoefficent, WorldWidth - BallRadius));

            if (WorldWidth - BallRadius == BallX || BallRadius == BallX)
                VelX = -VelX;

            VelX += cursorForceX;

            VelX *= 0.99;
        }

        public double boost = 50;
        public void OnKeyPress(KeyPressEventArgs e)
        {
            switch (e.KeyChar)
            {
                case 'W':
                case 'w':
                    VelY -= boost;
                    break;
                case 's':
                case 'S':
                    VelY += boost;
                    break;
                case 'a':
                case 'A':
                    VelX -= boost;
                    break;
                case 'd':
                case 'D':
                    VelX += boost;
                    break;
                case ' ':
                    VelX *= 0.7;
                    VelY *= 0.7;
                    break;
                case 'G':
                case 'g':
                    SwitchGravity();
                    break;
                case 'C':
                case 'c':
                    SwitchCursorForce();
                    break;
            }
        }

        public void SwitchGravity()
        {
            isGravityOn = !isGravityOn;
            BallColor = isGravityOn ? Brushes.GreenYellow : Brushes.Orange;
        }

        public void SwitchCursorForce()
        {
            isCursorForceOn = !isCursorForceOn;
        }

        public bool IsCursorForceOn()
        {
            return isCursorForceOn;
        }
    }
}
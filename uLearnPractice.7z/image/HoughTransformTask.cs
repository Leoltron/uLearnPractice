using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace Recognizer
{
	internal static class HoughTransformTask
	{
		public static Line[] HoughAlgorithm(double[,] original)
		{
		    var result = new List<Line>();
			var width = original.GetLength(0);
			var height = original.GetLength(1);

            var isBorderPoints = new bool[width,height];

            for(var x =0; x < width; x++)
                for (var y = 0; y < height; y++)
                    isBorderPoints[x, y] =original[x, y] == 0.0 &&
                                       MedianFilterTask.GetNeighbors(original, x, y, false).Contains(1.0);

            for (var x = 0; x < width; x++)
                for (var y = 0; y < height; y++)
                    if(isBorderPoints[x,y])
                        f(result,isBorderPoints,x,y,new Point(-1,-1));

		    return result.ToArray();
		}

	    public static void f(List<Line> lines, bool[,] points, int x, int y, Point source)
	    {
	        var width = points.GetLength(0);
	        var height = points.GetLength(1);

	        if (source.X >= 0)
	        {
	            points[x, y] = false;
	            lines.Add(new Line(source.X, source.Y, x, y));
	        }

	        for (var i = -1; i <= 1; i++)
	            for (var k = -1; k <= 1; k++)
	                if (!(x + i == source.X && y+k == source.Y) && x + i >= 0 && x + i < width && y + k >= 0 && y + k < height && points[x + i, y + k])
	                    f(lines, points, x + i, y + k, new Point(x, y));

	    }
	}
}
using System;
using System.Collections.Generic;

namespace Recognizer
{
	internal static class MedianFilterTask
	{
		public static double[,] MedianFilter(double[,] original)
		{
            var width = original.GetLength(0);
            var height = original.GetLength(1);
            var result = new double[width, height];

		    for (var x = 0; x < width; x++)
		        for (var y = 0; y < height; y++)
		            result[x, y] = GetMedian(GetNeighbors(original,x,y,true));
            return result;
		}

	    public static double GetMedian(double[] array)
	    {
            var len = array.Length;

            var sortedArray = new double[len];
            array.CopyTo(sortedArray,0);
            Array.Sort(sortedArray);

	        if (len%2 == 0)
	            return (sortedArray[len/2] + sortedArray[len/2 - 1])/2;
	        return sortedArray[len/2];
	    }

	    public static T[] GetNeighbors<T>(T[,] array, int i1, int i2, bool includeCenter)
	    {
	        var neighborsList = new List<T>();
	        for (var i = -1; i <= 1; i++)
	            for (var k = -1; k <= 1; k++)
                    if(includeCenter || (i!= 0 && k != 0))
                        TryAddArrElementToList(array,i1+i,i2+k,neighborsList);

            return neighborsList.ToArray();
	    }
        
        public static bool TryAddArrElementToList<T>(T[,] array, int i1, int i2, List<T> list)
	    {
	        if (i1 < 0 || i1 >= array.GetLength(0) || i2 < 0 || i2 >= array.GetLength(1)) return false;
	        list.Add(array[i1, i2]);
	        return true;
	    }
	}
}
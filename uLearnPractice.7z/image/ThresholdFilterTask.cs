﻿using System;
using System.Collections.Generic;

namespace Recognizer
{
	public static class ThresholdFilterTask
	{
	    private class DValuePoint:IComparable<DValuePoint>
        {
	        public int x;
	        public int y;
	        public double value;

	        public DValuePoint(int x, int y, double value)
	        {
	            this.x = x;
	            this.y = y;
	            this.value = value;
	        }

            public int CompareTo(DValuePoint other)
            {
                return value.CompareTo(other.value);
            }
        }
		/* 
		 * Замените пиксели ярче порогового значения T на белый (1.0),
		 * а остальные на черный (0.0).
		 * Пороговое значение найдите так, чтобы:
		 *  - если N — общее количество пикселей изображения, 
		 *    то хотя бы (int)(threshold*N)  пикселей стали белыми;
		 *  - белыми стало как можно меньше пикселей.
		*/

	    public static double[,] ThresholdFilter(double[,] original, double threshold)
	    {
	        var width = original.GetLength(0);
	        var height = original.GetLength(1);

            var whitePointsAmount = (int) (threshold*width*height);
	        var pointList = ToPointsList(original);


            return PointListToArray(pointList, whitePointsAmount, width, height);
	    }

	    private static double[,] PointListToArray(List<DValuePoint> pointList, int whitePointsAmount, int width, int height)
	    {
	        pointList.Sort();

            var result = new double[width, height];
            var i = 0;
	        for (; i < pointList.Count - whitePointsAmount; i++)
	            result[pointList[i].x, pointList[i].y] = 0.0;
	        while (i != 0 && i < pointList.Count && pointList[i].value == pointList[i - 1].value)
	        {
	            result[pointList[i].x, pointList[i].y] = 0.0;
	            i++;
	        }
	        while (i < pointList.Count)
	        {
	            result[pointList[i].x, pointList[i].y] = 1.0;
	            i++;
	        }

	        return result;
	    }

	    private static List<DValuePoint> ToPointsList(double[,] original)
	    {
            var width = original.GetLength(0);
            var height = original.GetLength(1);
            var pointList = new List<DValuePoint>();

            for (var x = 0; x < width; x++)
                for (var y = 0; y < height; y++)
                    pointList.Add(new DValuePoint(x, y, original[x, y]));
	        return pointList;
	    }
	}
}
﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace Manipulation
{
    public static class VisualizerTask
    {
        public static Form Form;

        private static string message;

        public static double X = 100;
        public static double Y = 100;
        public static double Angle;
        public static double Wrist = 2 * Math.PI / 3;
        public static double Elbow = 3 * Math.PI / 4;
        public static double Shoulder = Math.PI / 2;

        public static int StartX;
        public static int StartY;

        [STAThread]
        private static void Main()
        {
            InitializeForm();
            Application.Run(Form);
        }

        public static void InitializeForm()
        {
            Form = new AntiFlickerForm();
            Form.Text = "Manipulator";
            Form.ClientSize = new Size(500, 500);

            Form.Paint += Paint;
            Form.KeyDown += KeyDown;
            Form.MouseMove += MouseMove;
            Form.MouseWheel += MouseWheel;
            Form.Resize += Resize;

            UpdateStartCoords();
        }

        private static void UpdateStartCoords()
        {
            StartX = Form.ClientSize.Width/2;
            StartY = Form.ClientSize.Height - 20;
        }

        public static void Resize(object sender, EventArgs e)
        {
            UpdateStartCoords();
            Form.Invalidate();
        }

        public static void KeyDown(object sender, KeyEventArgs key)
        {
            message = "Вы нажали " + key.KeyCode;

            const double angleDelta = Math.PI / 18;
            const int positionDelta = 20;

            double dx = 0d,dy = 0d,dAngle = 0d;
            switch (key.KeyCode)
            {
                case Keys.W: dy += positionDelta; break;
                case Keys.A: dx -= positionDelta; break;
                case Keys.S: dy -= positionDelta; break;
                case Keys.D: dx += positionDelta; break;
                case Keys.R: dAngle += angleDelta; break;
                case Keys.F: dAngle -= angleDelta; break;
                default: return;
            }
            UpdateManipulatorState(X + dx, Y + dy, Angle + dAngle);
        }

        public static void MouseMove(object sender, MouseEventArgs e)
        {
            message = string.Format("Позиция мыши: ({0}, {1})", e.X, e.Y);
            var newX = e.X - StartX;
            var newY = StartY - e.Y;
            UpdateManipulatorState(newX, newY, Angle);
        }

        public static void MouseWheel(object sender, MouseEventArgs e)
        {
            var delta = Math.Sign(e.Delta) * Math.PI / 18;
            message = string.Format("Прокрутка на {0}°", delta / Math.PI * 180);
            UpdateManipulatorState(X, Y, Angle + delta);
        }

        private static void UpdateManipulatorState(double newX, double newY, double newAngle)
        {
            var angles = ManipulatorTask.MoveManipulatorTo(newX, newY, newAngle);
            if (angles.Contains(double.NaN)) return;
            X = newX; Y = newY;
            Angle = newAngle;
            Shoulder = angles[0]; Elbow = angles[1]; Wrist = angles[2];
            Form.Invalidate();
        }

        public static void Paint(object sender, PaintEventArgs e)
        {
            var graphics = e.Graphics;
            graphics.Clear(Color.Beige);
            graphics.SmoothingMode = SmoothingMode.HighQuality;

            var shoulderPoint = new Point(StartX, StartY);
            var elbowPoint = GetPointByOffset(shoulderPoint, Manipulator.UpperArm, Shoulder);
            var wristPoint = GetPointByOffset(elbowPoint, Manipulator.Forearm, Elbow + Shoulder + Math.PI);
            var fingerPoint = GetPointByOffset(wristPoint, Manipulator.Palm, Wrist + Shoulder + Elbow);

            graphics.FillRectangle(Brushes.Green, 0, StartY, Form.ClientSize.Width, 20);
            DrawManipulator(new[] { shoulderPoint, elbowPoint, wristPoint, fingerPoint }, graphics);
            if (message != null)
                graphics.DrawString(message, new Font("Arial", 14), Brushes.Blue, 0, 10);
        }

        private static void DrawManipulator(Point[] points, Graphics graphics)
        {
            var linePen = new Pen(Color.Black, 2);
            var circlePen = new Pen(Color.Red, 2);

            const int circleRadius = 10,circleDiameter = 20;
            for (var index = 0; index < points.Length - 1; index++)
            {
                var point = points[index];
                var nextPoint = points[index + 1];
                graphics.DrawLine(linePen, point.X, point.Y, nextPoint.X, nextPoint.Y);
                DrawFilledEllipseWithBorder(graphics, circlePen, Brushes.White,
                    point.X - circleRadius,
                    point.Y - circleRadius,
                    circleDiameter, circleDiameter);
            }
        }

        private static void DrawFilledEllipseWithBorder(Graphics graphics, Pen borderPen, Brush fillBrush,
            int x, int y, int width, int height)
        {
            graphics.FillEllipse(fillBrush, x, y, width, height);
            graphics.DrawEllipse(borderPen, x, y, width, height);
        }

        private static Point GetPointByOffset(Point point, double length, double angle)
        {
            return new Point((int)(point.X + length * Math.Cos(angle)),
                             (int)(point.Y - length * Math.Sin(angle)));
        }
    }
}
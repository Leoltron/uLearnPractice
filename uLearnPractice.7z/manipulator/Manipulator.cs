﻿namespace Manipulation
{
	internal static class Manipulator
	{
		public const double UpperArm = 150;
		public const double Forearm = 120;
		public const double Palm = 100;
	}
}
﻿using System;
using System.Linq;
using NUnit.Framework;

namespace Manipulation
{
    public class PointD
    {
        public readonly double X;
        public readonly double Y;

        public static readonly PointD Zero = new PointD(0,0);

        public PointD(double x, double y){X = x;Y = y;}

        public PointD Add(double dx, double dy)
        {
            return new PointD(X + dx, Y + dy);
        }

        public override string ToString() { return "X: " + X + " Y:" + Y; }

        public override bool Equals(object obj)
        {
            if (obj != null && GetType() == obj.GetType())
                return Equals((PointD)obj);
            return false;
        }

        public bool Equals(PointD pointD, double delta = 1e-5)
        {
            return Math.Abs(pointD.X - X) < delta && Math.Abs(pointD.Y - Y) < delta;
        }
    }

    public static class ManipulatorTask
    {
        public static double GetABAngle(double a, double b, double c)
        {
            if (a < 0 || b < 0 || c < 0)
                return double.NaN;
            return Math.Acos((b * b + a * a - c * c) / (2 * b * a));
        }

        internal static double GetLength(PointD a, PointD b)
        {
            var dx = a.X - b.X;
            var dy = a.Y - b.Y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

        public static PointD CalculateElbowPoint(PointD wristPoint, double angle, double upperArm)
        {
            var preElbP = new PointD(wristPoint.X * Math.Cos(angle) - wristPoint.Y * Math.Sin(angle)
                , wristPoint.X * Math.Sin(angle) + wristPoint.Y * Math.Cos(angle));

            var multiplier = upperArm / GetLength(PointD.Zero, wristPoint);
            return new PointD(preElbP.X * multiplier, preElbP.Y * multiplier);
        }

        public static double[] MoveManipulatorTo(double x, double y, double angle)
        {
            var basePoint = PointD.Zero;
            var fingerPoint = new PointD(x, y);
            var wristPoint = fingerPoint.Add(Manipulator.Palm * Math.Cos(Math.PI - angle),
                                                  Manipulator.Palm * Math.Sin(Math.PI - angle));

            var shoulderWristDistance = GetLength(basePoint, wristPoint);

            var elbowAngle = GetABAngle(Manipulator.Forearm, Manipulator.UpperArm, shoulderWristDistance);

            var elbowPoint = CalculateElbowPoint(wristPoint,
                        GetABAngle(shoulderWristDistance, Manipulator.UpperArm, Manipulator.Forearm),
                                                 Manipulator.UpperArm);

            var shoulderAngle = Math.Atan2(elbowPoint.Y, elbowPoint.X);
            var angles = new[] { shoulderAngle,
                                elbowAngle,
                                Math.PI*2 - shoulderAngle - elbowAngle - angle  };
            return angles.Contains(double.NaN) ? new[] { double.NaN, double.NaN, double.NaN } : angles;

        }
    }

    [TestFixture]
    public class ManipulatorTests
    {
        [TestCase(3, 4, 5, Math.PI / 2)]
        [TestCase(1, 1, 1, Math.PI / 3)]
        [TestCase(-1, 1, 1, double.NaN)]
        [TestCase(10000, 1, 1, double.NaN)]
        public void TestGetABAngle(double a, double b, double c, double expectedAngle)
        {
            Assert.AreEqual(expectedAngle, ManipulatorTask.GetABAngle(a, b, c), 0.0000000000001,
                "a:" + a + " b:" + b + " c:" + c);
        }

        [Test]
        public void TestMoveManipulatorToNaN()
        {
            Assert.AreEqual(new[] { double.NaN, double.NaN, double.NaN },
                ManipulatorTask.MoveManipulatorTo(
                    Manipulator.Forearm + Manipulator.UpperArm + Manipulator.Palm, 0, 1));
        }

        [Test]
        public void TestMoveManipulatorToRandom()
        {
            var rand = new Random();
            var maxLength = (Manipulator.Forearm + Manipulator.UpperArm + Manipulator.Palm) / Math.Sqrt(2);
            for (var i = 0; i < 100; i++)
            {

                var x = rand.NextDouble()*maxLength*2 - maxLength;
                var y = rand.NextDouble() * maxLength * 2 - maxLength;
                var expectedPoint = new PointD(x, y);

                var angle = rand.NextDouble() * Math.PI * 2 - Math.PI;

                var angles = ManipulatorTask.MoveManipulatorTo(expectedPoint.X, expectedPoint.Y, angle);

                var wristExpectedPoint = expectedPoint.Add(-Manipulator.Palm*Math.Cos(angle),
                    Manipulator.Palm*Math.Sin(angle));
                var wristPointVectorLength = ManipulatorTask.GetLength(PointD.Zero, wristExpectedPoint);
                var solutionExists = wristPointVectorLength <= Manipulator.UpperArm + Manipulator.Forearm 
                    && wristPointVectorLength >= Manipulator.UpperArm - Manipulator.Forearm;

                if (angles.Contains(double.NaN) && !solutionExists)
                    continue;

                var point = new PointD(0, 0);

                var message = "0 0";
                point = point.Add(Manipulator.UpperArm * Math.Cos(angles[0]), Manipulator.UpperArm * Math.Sin(angles[0]));
                message += " -> " + point.X + " " + point.Y;
                point = point.Add(Manipulator.Forearm * Math.Cos(angles[0] + angles[1] + Math.PI), Manipulator.Forearm * Math.Sin(angles[0] + angles[1] + Math.PI));
                message += " -> " + point.X + " " + point.Y;
                point = point.Add(Manipulator.Palm * Math.Cos(angles[0] + angles[1] + angles[2]), Manipulator.Palm * Math.Sin(angles[0] + angles[1] + angles[2]));
                message += " -> " + point.X + " " + point.Y;
                Assert.AreEqual(expectedPoint, point, message);
            }
        }
    }
}
﻿using System;

namespace HotelAccounting
{
    public class AccountingModel : ModelBase
    {
        private double price;

        public double Price
        {
            get { return price; }
            set
            {
                if (value < 0)
                    throw new ArgumentException();
                price = value;
                UpdateTotal();
                Notify(nameof(Price));
            }
        }

        private int nightsCount;

        public int NightsCount
        {
            get { return nightsCount; }
            set
            {
                if (value <= 0)
                    throw new ArgumentException();
                nightsCount = value;
                UpdateTotal();
                Notify(nameof(NightsCount));
            }
        }

        private double discount;

        public double Discount
        {
            get { return discount; }
            set
            {
                    discount = value;
                    UpdateTotal();
                    Notify(nameof(Discount));
            }
        }

        private double total;

        public double Total
        {
            get { return total; }
            set
            {
                if (value <= 0)
                    throw new ArgumentException();
                total = value;
                discount = (1 - value/Price/NightsCount)*100;
                Notify(nameof(Total));
            }
        }

        public AccountingModel():this(0d,1,0d){}

        public AccountingModel(double price, int nightsCount, double discount)
        {
            if (price < 0 || nightsCount <= 0)
                throw new ArgumentException();
            this.price = price;
            this.nightsCount = nightsCount;
            Discount = discount;
        }

        private void UpdateTotal()
        {
            var total = Price*NightsCount*(1 - Discount/100);
        }
    }
}
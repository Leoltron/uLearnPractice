﻿namespace Pluralize
{
	public static class PluralizeTask
	{
		public static string PluralizeRubles(int count)
		{
            int firstNum = count % 10;
            int secondNum = count < 10 ? -1 : count / 10 % 10;

            if (secondNum != 1)
                switch (firstNum)
                {
                    case 1:
                        return "рубль";
                    case 2:
                    case 3:
                    
                    case 4:
                        return "рубля";
                }
			return "рублей";
		}
	}
}
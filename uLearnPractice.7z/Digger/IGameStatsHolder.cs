﻿using System.Windows.Forms;

namespace Digger
{
    public interface IGameStatsHolder : ICreatureReadOnlyMap
    {
        Keys KeyPressed { get; }
        int Scores { get; set; }
        bool IsOver { get; set; }
    }
}
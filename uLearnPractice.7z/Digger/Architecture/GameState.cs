﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Digger
{
    public class GameState
    {
        public List<CreatureAnimation> animations = new List<CreatureAnimation>();

        public const int ElementSize = 32;

        private readonly ICreatureReadOnlyMap mapSource;

        public GameState(ICreatureReadOnlyMap mapSource)
        {
            this.mapSource = mapSource;
        }

        public void BeginAct()
        {
            animations.Clear();
            for (int x = 0; x < mapSource.MapWidth; x++)
                for (int y = 0; y < mapSource.MapHeight; y++)
                {
                    var creature = mapSource.Map[x, y];
                    if (creature == null) continue;
                    var command = creature.Act(x, y);

                    if (x + command.DeltaX < 0 || x + command.DeltaX >= mapSource.MapWidth || y + command.DeltaY < 0 || y + command.DeltaY >= mapSource.MapHeight)
                        throw new Exception($"The object {creature.GetType()} falls out of the game field");

                    animations.Add(new CreatureAnimation
                    {
                        Command = command,
                        Creature = creature,
                        Location = new Point(x * ElementSize, y * ElementSize),
                        TargetLogicalLocation = new Point(x+command.DeltaX, y+command.DeltaY)
                    });
                }
            animations = animations.OrderByDescending(z => z.Creature.DrawingPriority).ToList();
        }

        public void EndAct()
        {
            for (int x = 0; x < mapSource.MapWidth; x++)
                for (int y = 0; y < mapSource.MapHeight; y++)
                    mapSource.Map[x, y] = null;

            foreach (var e in animations)
            {
                var x = e.TargetLogicalLocation.X;
                var y = e.TargetLogicalLocation.Y;
                var nextCreature = e.Command.TransformTo == null ? e.Creature : e.Command.TransformTo;
                if (mapSource.Map[x, y] == null) mapSource.Map[x, y] = nextCreature;
                else
                {
                    bool newDead = nextCreature.DeadInConflict(mapSource.Map[x, y]);
                    bool oldDead = mapSource.Map[x, y].DeadInConflict(nextCreature);
                    if (newDead && oldDead)
                        mapSource.Map[x, y] = null;
                    else if (!newDead && oldDead)
                        mapSource.Map[x, y] = nextCreature;
                    else if (!newDead && !oldDead)
                        throw new Exception(string.Format("Существа {0} и {1} претендуют на один и тот же участок карты", nextCreature.GetType().Name, mapSource.Map[x, y].GetType().Name));
                }
            }
        }
    }
}

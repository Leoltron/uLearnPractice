﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Digger
{
	public class DiggerWindow : Form
    {
        Dictionary<string, Bitmap> bitmaps = new Dictionary<string, Bitmap>();
        GameState gameState;
        Game game;


        public DiggerWindow(Game game)
        {
            gameState = new GameState(game);
            this.game = game;
            ClientSize = new Size(GameState.ElementSize * game.MapWidth, GameState.ElementSize * game.MapHeight + GameState.ElementSize);
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            Text = "Digger";
            DoubleBuffered = true;

            var imagesDirectory = new DirectoryInfo("Images");
            foreach(var e in imagesDirectory.GetFiles("*.png"))
                bitmaps[e.Name]=(Bitmap)Bitmap.FromFile(e.FullName);
            var timer = new Timer();
            timer.Interval = 1;
            timer.Tick += TimerTick;
            timer.Start();
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            game.KeyPressed = e.KeyCode;
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            game.KeyPressed = Keys.None;
        }


        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.TranslateTransform(0, GameState.ElementSize);
            e.Graphics.FillRectangle(Brushes.Black,0,0, GameState.ElementSize * game.MapWidth, GameState.ElementSize *game.MapHeight);
            foreach(var a in gameState.animations)
                e.Graphics.DrawImage(bitmaps[a.Creature.ImageFileName],a.Location);
            e.Graphics.ResetTransform();
            e.Graphics.DrawString(game.Scores.ToString(), new Font("Arial", 16), Brushes.Green, 0, 0);
        }

        int tickCount = 0;

        void TimerTick(object sender, EventArgs args)
        {
            if (tickCount == 0) gameState.BeginAct();
            foreach (var e in gameState.animations)
                e.Location = new Point(e.Location.X + 4*e.Command.DeltaX, e.Location.Y + 4*e.Command.DeltaY);
            if (tickCount == 7)
                gameState.EndAct();

            tickCount++;
            if (tickCount == 8) tickCount = 0;
            Invalidate();
        }
    }
}

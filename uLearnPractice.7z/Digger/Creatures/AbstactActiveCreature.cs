﻿namespace Digger
{
    public abstract class AbstractActiveCreature : ICreature
    {
        protected readonly ICreatureReadOnlyMap MapSource;

        public abstract string ImageFileName { get; }
        public abstract int DrawingPriority { get; }
        public abstract CreatureCommand Act(int x, int y);
        public abstract bool DeadInConflict(ICreature conflictedObject);
        public abstract ICreature Copy();

        protected AbstractActiveCreature(ICreatureReadOnlyMap mapSource)
        {
            MapSource = mapSource;
        }
    }
}
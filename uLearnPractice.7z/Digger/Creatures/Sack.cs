namespace Digger
{
    public class Sack : AbstractActiveCreature
    {
        private int fallHeight;

        public override string ImageFileName => "Sack.png";
        public override int DrawingPriority => 2;

        public Sack(ICreatureReadOnlyMap mapSource) : base(mapSource) { }

        public override CreatureCommand Act(int x, int y)
        {
            if (y < MapSource.MapHeight - 1 && (!IsObstacle(MapSource.Map[x, y + 1])
                || (IsKillableBySack(MapSource.Map[x, y + 1]) && fallHeight > 0)))
            {
                fallHeight++;
                return new CreatureCommand { DeltaY = 1 };
            }
            if (fallHeight > 1)
                return new CreatureCommand { TransformTo = new Gold(MapSource) };
            fallHeight = 0;
            return new CreatureCommand();
        }

        public override bool DeadInConflict(ICreature conflictedObject)
        {
            return false;
        }

        public override ICreature Copy()
        {
            return new Sack(MapSource) {fallHeight = fallHeight};
        }

        public static bool IsObstacle(ICreature obj)
        {
            return obj is Terrain || obj is Sack || obj is Gold || obj is Player || obj is Monster;
        }

        private static bool IsKillableBySack(ICreature obj)
        {
            return obj is Player || obj is Monster;
        }

    }
}
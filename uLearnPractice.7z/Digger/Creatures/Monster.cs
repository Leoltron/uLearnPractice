using System;
using System.Drawing;

namespace Digger
{
    public class Monster : AbstractActiveCreature
    {
        public override string ImageFileName => "Monster.png";
        public override int DrawingPriority => 1;

        public Monster(ICreatureReadOnlyMap mapSource) : base(mapSource) { }

        private Point FindPlayerCoords()
        {
            for (var i = 0; i < MapSource.MapWidth; i++)
                for (var k = 0; k < MapSource.MapHeight; k++)
                    if (MapSource.Map[i, k] is Player)
                        return new Point(i, k);
            return Point.Empty;
        }

        public override CreatureCommand Act(int x, int y)
        {
            var playerCoords = FindPlayerCoords();
            var dX = Math.Sign(playerCoords.X - x);
            var dY = Math.Sign(playerCoords.Y - y);
            if (playerCoords == Point.Empty)
                return new CreatureCommand();
            if (!IsObstacle(MapSource.Map[x + dX, y]) && !(y > 0 && MapSource.Map[x + dX, y - 1] is Sack))
                return new CreatureCommand { DeltaX = dX };
            if (!IsObstacle(MapSource.Map[x, y + dY]) && !(y + dY > 0 && MapSource.Map[x, y + dY - 1] is Sack))
                return new CreatureCommand { DeltaY = dY };
            return new CreatureCommand();
        }

        public override bool DeadInConflict(ICreature conflictedObject)
        {
            return conflictedObject is Sack || conflictedObject is Monster;
        }

        public override ICreature Copy()
        {
            return new Monster(MapSource);
        }

        protected static bool IsObstacle(ICreature obj)
        {
            return obj is Monster || obj is Sack || obj is Terrain;
        }
    }
}
namespace Digger
{
    public class Terrain : ICreature
    {
        public string ImageFileName => "Terrain.png";
        public int DrawingPriority => 10;

        public CreatureCommand Act(int x, int y)
        {
            return new CreatureCommand();
        }

        public bool DeadInConflict(ICreature conflictedObject)
        {
            return conflictedObject is Player;
        }

        public ICreature Copy()
        {
            return new Terrain();
        }
    }
}
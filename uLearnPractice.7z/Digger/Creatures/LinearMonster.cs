using System;
using System.Drawing;

namespace Digger
{
    public class LinearMonster : Monster
    {
        private readonly Random rand;

        //0 - �����, 1- �����, 2 - ����, 3 - ������
        private readonly Point[] directions = { new Point(0, -1), new Point(-1, 0), new Point(0, 1), new Point(1, 0) };
        private int curDirectionNum;
        public override string ImageFileName => "LinearMonster.png";
        public override int DrawingPriority => 1;

        public LinearMonster(ICreatureReadOnlyMap mapSource) : base(mapSource)
        {
            rand = new Random();
            ChangeDirection();
        }

        public override CreatureCommand Act(int x, int y)
        {
            var dX = directions[curDirectionNum].X;
            var dY = directions[curDirectionNum].Y;
            if (IsInMapBounds(x + dX, y + dY) && !IsObstacle(MapSource.Map[x + dX, y + dY]))
                return new CreatureCommand { DeltaX = dX, DeltaY = dY };
            ChangeDirection();
            return new CreatureCommand();
        }

        private bool IsInMapBounds(int x, int y)
        {
            return x >= 0 && x < MapSource.MapWidth
                   && y >= 0 && y < MapSource.MapHeight;
        }

        public override bool DeadInConflict(ICreature conflictedObject)
        {
            if (conflictedObject is Player || conflictedObject is Gold)
                ChangeDirection();
            return base.DeadInConflict(conflictedObject);
        }

        private void ChangeDirection()
        {
            var prevDir = curDirectionNum;
            while (prevDir == curDirectionNum)
                curDirectionNum = rand.Next(directions.Length);
        }
    }
}
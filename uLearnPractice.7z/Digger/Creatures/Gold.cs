
namespace Digger
{

    public class Gold : AbstractActiveCreature
    {
        public const int ScoreValue = 10;

        public override string ImageFileName => "Gold.png";
        public override int DrawingPriority => 2;

        public Gold(ICreatureReadOnlyMap mapSource) : base(mapSource){}

        public override CreatureCommand Act(int x, int y)
        {
            if (y < MapSource.MapHeight - 1 && !Sack.IsObstacle(MapSource.Map[x, y + 1]))
                return new CreatureCommand {DeltaY = 1};
            return new CreatureCommand();
        }

        public override bool DeadInConflict(ICreature conflictedObject)
        {
            return conflictedObject is Player || conflictedObject is Monster;
        }

        public override ICreature Copy()
        {
            return new Gold(MapSource);
        }
    }
}
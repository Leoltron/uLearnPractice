﻿using System.Windows.Forms;

namespace Digger
{
    public class Player : ICreature
    {
        private const int Speed = 1;

        public string ImageFileName => "Digger.png";
        public int DrawingPriority => 0;

        private readonly IGameStatsHolder gameStats;

        public Player(IGameStatsHolder gameStats)
        {
            this.gameStats = gameStats;
        }

        public CreatureCommand Act(int x, int y)
        {
            switch (gameStats.KeyPressed)
            {
                case Keys.W:
                case Keys.Up:
                    if (y >= Speed && !(gameStats.Map[x, y - Speed] is Sack))
                        return new CreatureCommand { DeltaY = -Speed };
                    break;
                case Keys.A:
                case Keys.Left:
                    if (x >= Speed && !(gameStats.Map[x - Speed, y] is Sack))
                        return new CreatureCommand { DeltaX = -Speed };
                    break;
                case Keys.S:
                case Keys.Down:
                    if (y < gameStats.MapHeight - Speed && !(gameStats.Map[x, y + Speed] is Sack))
                        return new CreatureCommand { DeltaY = Speed };
                    break;
                case Keys.D:
                case Keys.Right:
                    if (x < gameStats.MapWidth - Speed && !(gameStats.Map[x + Speed, y] is Sack))
                        return new CreatureCommand { DeltaX = Speed };
                    break;
            }
            return new CreatureCommand();
        }

        public bool DeadInConflict(ICreature conflictedObject)
        {
            if (conflictedObject is Gold)
                gameStats.Scores += Gold.ScoreValue;
            var isDead = conflictedObject is Sack || conflictedObject is Monster;
            gameStats.IsOver = isDead;
            return isDead;
        }

        public ICreature Copy()
        {
            return new Player(gameStats);
        }
    }
}
﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Digger
{
    public class Game : IGameStatsHolder, IGameControlsAccessor
    {
        public ICreature[,] Map { get; private set; }
        public int MapWidth { get; }
        public int MapHeight { get; }
        public int Scores { get; set; }
        public bool IsOver { get; set; }

        public Keys KeyPressed
        {
            get { return keyPressed; }
            set
            {
                if(value == Keys.R)
                    Restart();
                keyPressed = value;
            }
        }

        private readonly bool isFileMode;
        private ICreature[,] defaultMap;
        private Keys keyPressed;

        public Game(int mapWidth, int mapHeight)
        {
            MapWidth = mapWidth;
            MapHeight = mapHeight;
            isFileMode = false;
            Restart();
        }

        public Game(string path)
        {
            var lines = File.ReadLines(path).ToArray();
            MapHeight = lines.Length;
            if(MapHeight == 0)
                throw new FileFormatException("Line amount must be more than zero!");
            MapWidth = lines[0].Length;
            if(MapWidth == 0)
                throw new FileFormatException("Line length must be more than zero!");
            isFileMode = true;
            try
            {
                for (var y = 0; y < MapHeight; y++)
                    for (var x = 0; x < MapWidth; x++)
                    {
                        defaultMap[x, y] = GetCreature(lines[y][x]);
                    }
            }
            catch (IndexOutOfRangeException)
            {
                throw new FileFormatException();
            }
            Restart();
        }

        private ICreature GetCreature(char c)
        {
            switch (c)
            {
                case 'M':
                    return new Monster(this);
                case 'L':
                    return new LinearMonster(this);
                case 'G':
                    return new Gold(this);
                case 'S':
                    return new Sack(this);
                case 'P':
                    return new Player(this);
                case 'T':
                    return new Terrain();
                default:
                    return null;
            }
        }

        public void Restart()
        {
            IsOver = false;
            Scores = 0;
            if (isFileMode)
            {
                Map =  new ICreature[MapWidth,MapHeight];
                for (var x = 0; x < MapWidth; x++)
                    for (var y = 0; y < MapHeight; y++)
                        Map[x, y] = defaultMap[x, y].Copy();
            }
            else
                CreateRandomMap();

        }

        private void CreateRandomMap()
        {
            var rand = new Random();

            Map = new ICreature[MapWidth, MapHeight];
            FillMap(Map);

            for (var i = 0; i < 25; i++)
                AddCreature(rand, Map, new Sack(this), false);
            for (var i = 0; i < 5; i++)
                AddLine(rand,new LinearMonster(this), Map);

            for (var i = 0; i < 5; i++)
                AddLine(rand, new Monster(this), Map);

            AddCreature(rand, Map, new Player(this), true);
        }

        private void FillMap(ICreature[,] map)
        {
            for (var i = 0; i < MapWidth; i++)
                for (var j = 0; j < MapHeight; j++)
                    map[i, j] = new Terrain();
        }

        private void AddCreature(Random rand, ICreature[,] map, ICreature creature, bool checkForSafe)
        {
            var x = rand.Next(MapWidth);
            var y = rand.Next(MapHeight);
            while (!((map[x, y] == null || map[x, y] is Terrain) && (!checkForSafe || IsSafePlace(x, y))))
            {
                x = rand.Next(MapWidth);
                y = rand.Next(MapHeight);
            }
            map[x, y] = creature;
        }

        private void AddLine(Random rand,ICreature monster, ICreature[,] map)
        {
            var isHorizontal = rand.Next(2) == 0;
            var length = rand.Next((isHorizontal ? MapWidth : MapHeight)-1) + 2;
            var pos = rand.Next(isHorizontal ? MapHeight : MapWidth);
            var startPoint = rand.Next((isHorizontal ? MapWidth : MapHeight) - length);
            var monsterPoint = rand.Next(length);
            if (isHorizontal)
                for (var i = 0; i < length; i++)
                    map[startPoint + i, pos] = i == monsterPoint ? monster : null;
            else
                for (var i = 0; i < length; i++)
                    map[pos, startPoint + i] = i == monsterPoint ? monster : null;

        }

        private bool IsSafePlace(int x, int y )
        {
            return SafeIsTerrain(x + 1, y, false)
                   && SafeIsTerrain(x - 1, y, false)
                   && SafeIsTerrain(x, y + 1, false)
                   && SafeIsTerrain(x, y - 1, false);
        }

        private bool SafeIsTerrain(int x, int y, bool defaultIs)
        {
            try
            {
                return Map[x, y] is Terrain;
            }
            catch (IndexOutOfRangeException)
            {
                return defaultIs;
            }
        }
    }
}

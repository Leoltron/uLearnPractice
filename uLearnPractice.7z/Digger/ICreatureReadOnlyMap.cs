﻿namespace Digger
{
    public interface ICreatureReadOnlyMap
    {
        ICreature[,] Map { get; }
        int MapWidth { get; }
        int MapHeight { get; }
    }
}
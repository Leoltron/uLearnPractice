﻿using System.Windows.Forms;

namespace Digger
{
    public interface IGameControlsAccessor
    {
        Keys KeyPressed { set; }
        int Scores { get; }
        int MapWidth { get; }
        int MapHeight { get; }
    }
}
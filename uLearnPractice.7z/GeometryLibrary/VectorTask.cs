﻿using System;

namespace GeometryTasks
{
    public class Vector
    {
        public double X;
        public double Y;

        public Vector(double x, double y)
        {
            X = x;
            Y = y;
        }

        public Vector()
        {
            X = 0;
            Y = 0;
        }

        public double GetLength()
        {
            return Geometry.GetLength(this);
        }

        public bool Belongs(Segment seg)
        {
            return Geometry.IsVectorInSegment(this, seg);
        }
    }


    public class Segment
    {
        public Vector Begin;
        public Vector End;

        public Segment(Vector begin, Vector end)
        {
            Begin = begin;
            End = end;
        }

        public Segment()
        {
            Begin = new Vector();
            End = new Vector();
        }

        public double GetLength()
        {
            return Geometry.GetLength(this);
        }

        public bool Contains(Vector vec)
        {
            return Geometry.IsVectorInSegment(vec, this);
        }
    }

    public static class Geometry
    {

        public static bool IsVectorInSegment(Vector vec, Segment seg)
        {
            return Math.Abs(GetLength(new Segment(seg.Begin, vec))
                            + GetLength(new Segment(vec, seg.End)) - GetLength(seg)) < 1e-5;
        }

        public static double GetLength(Segment seg)
        {
            var dx = seg.Begin.X - seg.End.X;
            var dy = seg.Begin.Y - seg.End.Y;
            return Math.Sqrt(dx*dx + dy*dy);
        }

        public static double GetLength(Vector vec)
        {
            return Math.Sqrt(vec.X*vec.X + vec.Y*vec.Y);
        }

        public static Vector Add(Vector vec1, Vector vec2)
        {
            return new Vector(vec1.X + vec2.X, vec1.Y + vec2.Y);
        }
    }
}
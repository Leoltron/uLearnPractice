﻿
using System;

namespace ReadOnlyVectorTask
{
    public class ReadOnlyVector
    {
        public readonly double X;
        public readonly double Y;

        public ReadOnlyVector(double x, double y)
        {
            X = x;
            Y = y;
        }

        public ReadOnlyVector()
        {
            X = 0;
            Y = 0;
        }

        public ReadOnlyVector Add(ReadOnlyVector other)
        {
            return new ReadOnlyVector(X + other.X,Y + other.Y);
        }

        public ReadOnlyVector WithX(double y)
        {
            return new ReadOnlyVector(X, y);
        }

        public ReadOnlyVector WithY(double x)
        {
            return new ReadOnlyVector(x, Y);
        }

        public override bool Equals(object obj)
        {
            if(obj is ReadOnlyVector)
                return Equals((ReadOnlyVector)obj);
            return false;
        }

        public bool Equals(ReadOnlyVector other)
        {
            return Math.Abs(other.X - X) < 1e-5 && Math.Abs(other.Y - Y) < 1e-5;
        }
    }
}

﻿using System;

namespace Billiards
{
	public static class BilliardsTask
	{
		public static double BounceWall(double directionRadians, double wallInclanationRadians)
		{
            return -directionRadians + wallInclanationRadians * 2;
		}
	}
}
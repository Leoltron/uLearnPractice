﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Seminar;

namespace SeminarTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void BeginningTest()
        {
            var array = new long[] {1, 1, 1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
            Assert.AreEqual(-1, RecursiveBinarySearchTask.BinSearchLeftBorder(array, 1, -1, array.Length),
                RecursiveBinarySearchTask.log);
        }

        [TestMethod]
        public void InnerTest()
        {
            var array = new long[] { 0, 1, 1, 1, 2, 4, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
            Assert.AreEqual(0, RecursiveBinarySearchTask.BinSearchLeftBorder(array, 1, -1, array.Length),
                RecursiveBinarySearchTask.log);
        }

        [TestMethod]
        public void LastTest()
        {
            var array = new long[] { 0, 1, 1, 1, 2, 4, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
            Assert.AreEqual(array.Length-2, RecursiveBinarySearchTask.BinSearchLeftBorder(array, 16, -1, array.Length),
                RecursiveBinarySearchTask.log);

            FindLeftBorder(new long[] {1, 2, 3}, 2,0);
            FindLeftBorder(new long[] { 1, 2, 3 }, 3,1);
            FindLeftBorder(new long[] { 1, 2, 3 }, 4,2);
            FindLeftBorder(new long[] { 1 }, 2,0);
            FindLeftBorder(new long[] { 1, 1 }, 2,1);
            FindLeftBorder(new long[] { 1, 2, 2, 3 }, 2,0);
            FindLeftBorder(new long[] { 1, 2, 2, 2, 3 }, 2,0);
            FindLeftBorder(new long[] { 1, 1, 1, 2, 3 }, 2,2);
        }

        public void FindLeftBorder(long[] array, int ind, int expected)
        {
            Assert.AreEqual(expected, RecursiveBinarySearchTask.BinSearchLeftBorder(array, ind, -1, array.Length),
               RecursiveBinarySearchTask.log);
        }

    }
}

﻿using System;

namespace Fractals
{
    internal static class DragonFractalTask
    {
        public static void DrawDragonFractal(Pixels pixels, int iterationsCount, int seed)
        {
            var rand = new Random(seed);
            double x = 1.0, x1;
            double y = 0.0, y1;

            var sin45Deg = Math.Sin(Math.PI / 4);
            var cos45Deg = Math.Cos(Math.PI / 4);
            
            var sin135Deg = Math.Sin(Math.PI / 4 * 3);
            var cos135Deg = Math.Cos(Math.PI / 4 * 3);

            var sqrt2 = Math.Sqrt(2);

            for (int i = 0; i < iterationsCount; i++)
            {
                if (rand.Next() >= 0.5)
                {                    
                    x1 = ((x * cos45Deg) - (y * sin45Deg)) / sqrt2;
                    y1 = ((x * sin45Deg) + (y * cos45Deg)) / sqrt2;
                }
                else
                {                    
                    x1 = (x * cos135Deg - y * sin135Deg) / sqrt2 + 1;
                    y1 = (x * sin135Deg + y * cos135Deg) / sqrt2;
                }
                x = x1;
                y = y1;

                pixels.SetPixel(x, y);
            }
        }
    }
}
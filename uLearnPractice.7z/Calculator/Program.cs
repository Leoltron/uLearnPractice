﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine(Calculate(Console.ReadLine()));
        }

        public static double Calculate(string userInput)
        {
            string[] args = userInput.Split(' ');

            double sum = double.Parse(args[0]);
            double monthlyMultiplier = double.Parse(args[1]) / 100 / 12 + 1;
            int lengthMonths = int.Parse(args[2]);

            return Math.Pow(monthlyMultiplier, lengthMonths) * sum;
        }
    }
}

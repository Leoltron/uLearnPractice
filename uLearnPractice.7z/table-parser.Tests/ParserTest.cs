﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TableParser;

namespace table_parser.Tests
{
    [TestClass]
    public class ParserTest
    {
        [TestMethod]
        public void RunTests()
        {
            Test("hello world", new[] { "hello", "world" });
            Test("hello                 world", new[] { "hello", "world" });
            Test("", new string[] { });
            Test("\\\"\\\"\"", new[] { "\\", "\"" });
            Test(" hello world ", new[] { "hello", "world" });
            Test("helloworld", new[] { "helloworld" });
            Test("\"hello world\"", new[] { "hello world" });
            Test("a \"bcd ef\" 'x y'", new[] { "a", "bcd ef", "x y" });
            Test("abc \"de f\"", new[] { "abc", "de f" });
            Test("abc \"def", new[] { "abc", "def" });
            Test("a\"bcde\"f", new[] { "a", "bcde", "f" });
            //Test("a\"b c d e\"f", new[] { "a", "b c d e", "f" });
            Test("abc \"defgh", new[] { "abc", "defgh" });
            Test("abc 'defgh", new[] { "abc", "defgh" });
            Test("\"a'b''c'd\" '\"1\"\"2\"\"3\"'", new[] { "a'b''c'd", "\"1\"\"2\"\"3\"" });
            //Test("\"a'b''c'd\" '\\'1\\'\\'2\\'\\'3\\''", new[] { "a'b''c'd", "'1''2''3''" });
            Test("\"a \\\"c\\\"\"", new[] { "a \"c\"" });
            Test("\"\"b", new[] { "", "b" });
            Test("\"\\\\\"", new[] { "\\" });
            //Test("\\\\ \"\\\\\"", new[] { "\\","\\" });
            Test("\" \"", new[] { " " });
            //Test("\"\\\\\"b", new[] { "\\", "b" });

        }

        private static int t = 13;
        private static void Test(string input, string[] expectedOutput)
        {
            Assert.IsTrue(T(expectedOutput,FieldsParserTask.ParseLine(input).ToArray()),t+": "+ input+" : "+ TS(expectedOutput)+" != "+ TS(FieldsParserTask.ParseLine(input).ToArray()));
            t++;
        }

        private static bool T(string[] a, string[] b)
        {
            if (a.Length != b.Length)
                return false;

            return !a.Where((t1, i) => t1 != b[i]).Any();
        }

        private static string TS(string[] a)
        {
            if (a == null) throw new ArgumentNullException(nameof(a));
            if (a.Length == 0)
                return "[]";
            var s = '['+a[0];
            for (var i = 1; i < a.Length; i++)
                s = s + ',' + a[i];
            return s+']';
        }
    }
}

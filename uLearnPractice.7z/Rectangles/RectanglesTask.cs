﻿using System;

namespace Rectangles
{
    public class Point
    {
        public readonly int x;
        public readonly int y;

        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
    }

	public static class RectanglesTask
	{

        public static Point[] GetRectCorners(Rectangle r)
        {
            Point[] points = new Point[4];

            points[0] = new Point(r.Left, r.Top);
            points[1] = new Point(r.Right, r.Top);
            points[2] = new Point(r.Left, r.Bottom);
            points[3] = new Point(r.Right, r.Bottom);

            return points;
        }

        public static bool IsPointInsideRect(Rectangle rectangle, Point point)
        {
            return rectangle.Left <= point.x
                && rectangle.Right >= point.x
                && rectangle.Top <= point.y
                && rectangle.Bottom >= point.y;
        }

		public static bool AreIntersected(Rectangle r1, Rectangle r2)
		{
            return r1.Left <= r2.Right && r1.Right >= r2.Left && r1.Top <= r2.Bottom && r1.Bottom >= r2.Top;
        }

		public static int IntersectionSquare(Rectangle r1, Rectangle r2)
		{
            if (AreIntersected(r1, r2))
                return (Math.Min(r1.Right, r2.Right) - Math.Max(r1.Left, r2.Left))
                    * (Math.Min(r1.Bottom, r2.Bottom) - Math.Max(r1.Top, r2.Top));

            return 0;
		}

        public static bool IsRectInsideAnother(Rectangle r1, Rectangle r2)
        {
            Point[] rectangleCorners = GetRectCorners(r1);

            bool isInside = true;

            foreach (Point point in rectangleCorners)
            {
                isInside = isInside && IsPointInsideRect(r2, point);
            }

            return isInside;
        }
        
        public static int IndexOfInnerRectangle(Rectangle r1, Rectangle r2)
		{
			return IsRectInsideAnother(r1,r2) ? 0 : (IsRectInsideAnother(r2, r1) ? 1 : - 1);
		}
	}
}